export type AwardItems = {
  ID: string;
  Title: string;
  Designation: string;
  UserImage: string;
  ImageUrl: string;
};
