import { AwardItems } from "./AwardItems";

export interface ContentProps {
  user: AwardItems | null;
}
